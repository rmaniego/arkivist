""" arkivist """
version = "1.1.34"
url = "https://github.com/rmaniego/arkivist"