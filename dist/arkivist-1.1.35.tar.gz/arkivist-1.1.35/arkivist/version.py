""" arkivist """
version = "1.1.35"
url = "https://github.com/rmaniego/arkivist"