""" arkivist """
version = "1.1.37"
url = "https://github.com/rmaniego/arkivist"