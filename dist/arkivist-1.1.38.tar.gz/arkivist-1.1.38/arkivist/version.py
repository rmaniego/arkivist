""" arkivist """
version = "1.1.38"
url = "https://github.com/rmaniego/arkivist"