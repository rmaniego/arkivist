""" arkivist """
version = "1.1.39"
url = "https://github.com/rmaniego/arkivist"