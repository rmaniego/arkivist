""" arkivist """
version = "1.1.40"
url = "https://github.com/rmaniego/arkivist"