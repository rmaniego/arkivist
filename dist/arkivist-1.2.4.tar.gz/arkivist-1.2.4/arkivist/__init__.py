""" arkivist """
__version__ = "1.2.4"
from .arkivist import Arkivist
__all__ = ["arkivist"]